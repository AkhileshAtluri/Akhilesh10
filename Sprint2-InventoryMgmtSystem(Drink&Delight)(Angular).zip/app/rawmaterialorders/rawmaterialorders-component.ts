import { Component, OnInit } from '@angular/core';
import { RawMaterialOrdersService } from './rawmaterialorders-service';
import { RawMaterialOrders } from './rawmaterialorders';
@Component({
	selector : 'rawmaterial',
	templateUrl : './rawmaterialorders-component.html'
})
export class RawMaterialOrdersComponent implements OnInit
{
    rawMaterialOrders:RawMaterialOrders = new RawMaterialOrders(0,'',0,0,0,0,0,'','','','');
 
    public constructor(private rawMaterialOrdersService:RawMaterialOrdersService){}
    
    public getRawMaterialOrder():void
    {
	this.rawMaterialOrdersService.getRawMaterialOrder(this.rawMaterialOrders.orderId).subscribe(data => this.rawMaterialOrders = data );
    }
    
    public deleteRawMaterialOrder() : void
    {
	this.rawMaterialOrdersService.deleteRawMaterialOrder(this.rawMaterialOrders.orderId).subscribe();
    }

    public addRawMaterialOrder() : void
    {
	this.rawMaterialOrdersService.addRawMaterialOrder(this.rawMaterialOrders).subscribe();
    }

    public updateRawMaterialOrder() : void
    {
	this.rawMaterialOrdersService.updateRawMaterialOrder(this.rawMaterialOrders).subscribe();
    }

    ngOnInit(){}
}