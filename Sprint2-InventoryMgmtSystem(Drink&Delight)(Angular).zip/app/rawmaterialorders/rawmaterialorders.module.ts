import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms'; 
import { CommonModule } from '@angular/common';
import { RawMaterialOrdersService } from './rawmaterialorders-service';
import { RawMaterialOrdersComponent } from './rawmaterialorders-component';
import { RawMaterialOrdersListComponent } from './rawmaterialorderslist-component';
@NgModule({
  
   declarations: [
  RawMaterialOrdersComponent, RawMaterialOrdersListComponent    ],
 
   imports: [
    HttpClientModule, FormsModule , CommonModule ],
  
   providers: [ RawMaterialOrdersService ],
 
   exports: [ RawMaterialOrdersComponent, RawMaterialOrdersListComponent ]
})
export class RawMaterialOrdersModule
{
}