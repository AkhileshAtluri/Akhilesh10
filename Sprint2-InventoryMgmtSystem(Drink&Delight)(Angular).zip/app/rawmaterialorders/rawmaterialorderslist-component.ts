import { Component, OnInit } from '@angular/core';
import { RawMaterialOrdersService } from './rawmaterialorders-service';
import { RawMaterialOrders } from './rawmaterialorders';
@Component({
	selector : 'rawmaterialorders-list',
	templateUrl : './rawmaterialorderslist-component.html'
})
export class RawMaterialOrdersListComponent implements OnInit
{
	rawMaterialOrders:RawMaterialOrders[];
	public constructor(private rawMaterialOrdersService:RawMaterialOrders){}
	
	public getRawMaterialOrders():void
	{
	    this.rawMaterialOrdersService.getRawMaterialOrders().subcribe(data => this.rawMaterialOrders = data);
	}
	ngOnInit(){}
}