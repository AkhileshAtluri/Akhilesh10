Export Class RawMaterialOrders
{
    orderId:number;
    rawMaterialName:String;
    pricePerUnit:number;
    quantityValue:number;
    totalPrice:number;
    wareHouseId:number;
    supplierId:number;
    delivreyDate:String;
    manufacturingDate:String;
    expiryDate:String;
    deliveryStatus:String;
    public constructor(orderId:number, rawMaterialName:String, pricePerUnit:number, quantityValue:nummber, totalPrice:number,wareHouseId:number,
		       supplierId:number, deliveryDate:String, manufacturingDate:String, expiryDate:String, deliveryStatus:String)
    {
	this.orderId = orderId;
	this.rawMaterialName = rawMaterialName;
	this.pricePerUnit = pricePerUnit;
	this.quantityValue = quantityValue;
	this.totalPrice = totalPrice;
	this.wareHouseId = wareHouseId;
	this.SupplierId = supplierId;
	this.deliveryDate = deliveryDate;
	this.manufacturingDate = manufacturingDate;
	this.expiryDate = expiryDate;
	this.deliveryStatus = deliveryStatus;
    }
}