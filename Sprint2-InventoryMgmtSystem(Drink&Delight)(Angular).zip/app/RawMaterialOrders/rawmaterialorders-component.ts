import { Component, OnInit } from '@angular/core';
import { RawMaterialOrdersService } from './rawmaterialorders-service';
import { RawMaterialOrders } from './rawmaterailorders';
@Component({
	selector : 'add-rawmaterial',
	templateUrl : './rawmaterialorders-component.html';
})
export class RawMaterialOrdersComponent implements OnInit
{
    rawMaterialOrders:RawMaterialOrders = new RawMaterialOrders(0,'',0,0,0,0,0,'','','','');
    public constructor(private rawMaterialOrdersService:RawMaterialOrdersService){}
    
    public getRawMaterialOrders():void
    {
	this.rawMaterialOrdersService.getRawMaterialOrders(this.rawMaterialOrders.orderId).subcribe(data => this.rawMaterialOrders = data );
    }
    
    public deleteRawMaterialOrder() : void
    {
	this.rawMaterialOrdersService.deleteRawMaterialOrder(this.rawMaterialOrder.orderId).subcribe();
    }

    public addRawMaterialOrder() : void
    {
	this.rawMaterialOrdersService.addRawMaterialOrder(this.rawMaterialOrders).subscribe();
    }

    public updateRawMaterialOrder() : void
    {
	this.rawMaterialOrdersService.updateRawMaterialOrder(this.rawMaterialOrders).subcribe();
    }

    ngOnInit(){}
}