package com.cg.anurag.b4.ims.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
//import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.cg.anurag.b4.ims.dto.RawMaterialOrders;
import com.cg.anurag.b4.ims.service.RawMaterialOrdersService;

//@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class RawMaterialOrdersController 
{
	@Autowired
	RawMaterialOrdersService rmoService;
	public void setRmoService(RawMaterialOrdersService rmoService) 
	{
		this.rmoService = rmoService;
	}
	
	@GetMapping(value="/getAllOrders")
	public List<RawMaterialOrders> getAllOrders()
	{
		return rmoService.getAllDetails();
	}
	
	@GetMapping(value = "/getOrderDetails/{orderId}")
	public ResponseEntity<Optional<RawMaterialOrders>> getOrder(@PathVariable String orderId)
	{
		Optional<RawMaterialOrders> rawMaterial = rmoService.getDetails(orderId);
		if(rawMaterial.isPresent())
			return new ResponseEntity<Optional<RawMaterialOrders>>(rawMaterial,HttpStatus.OK);
		return new ResponseEntity<Optional<RawMaterialOrders>>(rawMaterial,HttpStatus.NOT_FOUND);
	}
	
	@DeleteMapping("/deleteOrder/{orderId}")
	public ResponseEntity<String> deleteOrder(@PathVariable String orderId)
	{
		try
		{
			rmoService.deleteOrder(orderId);
			return new ResponseEntity<String>("Deleted Successfully",HttpStatus.OK);
		}
		catch(Exception ex)
		{
			return new ResponseEntity<String>("Deletion Failed",HttpStatus.BAD_REQUEST);
		}
	}
	@PostMapping(value="/addRawMaterial",consumes="application/json")
    public ResponseEntity<String> addRawMaterialDetails(@RequestBody() RawMaterialOrders rm)
    {
  	  try
  	  {
  	      rmoService.addRawmaterial(rm);
  	      return new ResponseEntity<String>("RawMaterial Added",HttpStatus.OK);
  	  }
  	  catch(Exception ex)
  	  {
  	    	return new ResponseEntity<String>(ex.getMessage()+" Insertion Failed",HttpStatus.BAD_REQUEST);
  	  } 
    }
    
    /*@PutMapping(value="/updateUser",consumes="application/json")
    public void updateUserDetails(@RequestBody() User user)
    {
  	    userService.updateUser(user);
    }*/
}
