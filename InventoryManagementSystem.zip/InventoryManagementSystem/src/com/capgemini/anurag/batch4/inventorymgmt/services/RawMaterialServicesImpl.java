package com.capgemini.anurag.batch4.inventorymgmt.services;

import java.util.List;

import com.capgemini.anurag.batch4.inventorymgmt.dao.RawMaterialDao;
import com.capgemini.anurag.batch4.inventorymgmt.dao.RawMaterialDaoImpl;
import com.capgemini.anurag.batch4.inventorymgmt.dto.DisplayRawMaterial;
import com.capgemini.anurag.batch4.inventorymgmt.dto.PlaceAnOrderRawMaterial;
import com.capgemini.anurag.batch4.inventorymgmt.dto.UpdateAnOrderRawMaterial;

public class RawMaterialServicesImpl implements RawMaterialSevices
{
	RawMaterialDao dao = new RawMaterialDaoImpl();
	@Override
	public List<PlaceAnOrderRawMaterial> placeAnOrder() {
		return dao.placeAnOrder();
	}

	@Override
	public int updateAnOrder(UpdateAnOrderRawMaterial u) {
		return dao.updateAnOrder(u);
	}

	@Override
	public DisplayRawMaterial display(double supplierId) 
	{
		return dao.display(supplierId);
	}

}
