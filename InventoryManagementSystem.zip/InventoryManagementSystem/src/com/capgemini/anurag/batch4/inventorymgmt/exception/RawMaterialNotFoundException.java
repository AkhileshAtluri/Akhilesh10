package com.capgemini.anurag.batch4.inventorymgmt.exception;

public class RawMaterialNotFoundException extends Exception{
	public RawMaterialNotFoundException()
	{
		super("Please Enter Valid RawMaterial Name");
	}
}
