package com.capgemini.anurag.batch4.inventorymgmt.application;

import java.util.List;
import java.util.Scanner;
import com.capgemini.anurag.batch4.inventorymgmt.dto.DisplayRawMaterial;
import com.capgemini.anurag.batch4.inventorymgmt.dto.PlaceAnOrderProduct;
import com.capgemini.anurag.batch4.inventorymgmt.dto.PlaceAnOrderRawMaterial;
import com.capgemini.anurag.batch4.inventorymgmt.dto.UpdateAnOrderProduct;
import com.capgemini.anurag.batch4.inventorymgmt.dto.UpdateAnOrderRawMaterial;
import com.capgemini.anurag.batch4.inventorymgmt.services.RawMaterialServicesImpl;
import com.capgemini.anurag.batch4.inventorymgmt.services.RawMaterialSevices;
import com.capgemini.anurag.batch4.inventorymgmt.exception.ProductNotFoundException;
import com.capgemini.anurag.batch4.inventorymgmt.exception.RawMaterialNotFoundException;
import com.capgemini.anurag.batch4.inventorymgmt.exception.WareHouseIdNotFoundException;

public class RawMaterialDetails {

	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		RawMaterialSevices rms = new RawMaterialServicesImpl();
		try
		{
			List<PlaceAnOrderRawMaterial> rmlist = rms.placeAnOrder();
			System.out.println("Name\t\tsupplierid\twarehouseid\tpriceperunit");
			for(PlaceAnOrderRawMaterial rm : rmlist)
			System.out.println(rm.getName()+"\t"+rm.getSupplierId()+"\t\t"+rm.getWareHouseId()+"\t\t"+rm.getPricePerUnit());

		}
		catch(Exception e)
		{
			System.out.println("Order not Placed");
		}
		System.out.println("Enter RawMaterial Name to be Order");
		String RawMaterialName = sc.nextLine();
		System.out.println("Enter Supplier Id");
		double supplierId = sc.nextDouble();
		System.out.println("Enter WareHouse Id");
		double wareHouseId = sc.nextDouble();
		System.out.println("Enter Quantity Required");
		double quantityValue = sc.nextDouble();
		double orderId = 1;
		UpdateAnOrderRawMaterial u1 = new UpdateAnOrderRawMaterial(orderId, "Processed", RawMaterialName, supplierId, wareHouseId, quantityValue);
		try
		{
			int rows = rms.updateAnOrder(u1);
			if(rows>0)
				System.out.println("Updated");
			else
				System.out.println("Not Updated");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		try
		{
		DisplayRawMaterial dp = rms.display(50);
		System.out.println(dp.getOrderId()+" "+dp.getName()+" "+dp.getPricePerUnit()+" "+
		dp.getQuantityValue()+" "+dp.getQuantityUnit()+" "+dp.getPrice()+" "+dp.getWareHouseId()+
		" "+dp.getDeliveryDate()+" "+dp.getManufactureDate()+" "+dp.getExpiryDate()+" "+
		dp.getQualityCheck()+" "+dp.getProcessDate());
		}
		catch(NullPointerException e)
		{
			System.out.println("No RawMaterials");
		}
	}

}
