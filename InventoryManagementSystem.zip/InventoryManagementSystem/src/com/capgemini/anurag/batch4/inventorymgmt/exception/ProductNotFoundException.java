package com.capgemini.anurag.batch4.inventorymgmt.exception;

public class ProductNotFoundException extends Exception
{
	public ProductNotFoundException()
	{
		super("Please Enter Available Product Name");
	}
}
