package com.capgemini.anurag.batch4.inventorymgmt.testing;

import java.util.ArrayList;
import java.util.List;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import com.capgemini.anurag.batch4.inventorymgmt.dao.ProductDao;
import com.capgemini.anurag.batch4.inventorymgmt.dao.ProductDaoImpl;
import com.capgemini.anurag.batch4.inventorymgmt.dao.RawMaterialDao;
import com.capgemini.anurag.batch4.inventorymgmt.dao.RawMaterialDaoImpl;
import com.capgemini.anurag.batch4.inventorymgmt.dto.PlaceAnOrderProduct;
import com.capgemini.anurag.batch4.inventorymgmt.dto.PlaceAnOrderRawMaterial;

public class JunitTestCase 
{
	ProductDao p = null;
	RawMaterialDao r = null;
	int a = 0;
	@Before
	public void setUp()
	{
		p = new ProductDaoImpl();
		r = new RawMaterialDaoImpl();
	}
	@After
	public void tearDown()
	{
		p = null;
		r = null;
	}
	@Test
	public void testPositiveCase() 
	{
		List<PlaceAnOrderProduct> arr = new ArrayList();
		arr = p.placeAnOrder();
		if(arr.size()>0)
			a=1;
		Assert.assertEquals(a,1);
		List<PlaceAnOrderRawMaterial> arr1 = new ArrayList();
		arr1 = r.placeAnOrder();
		if(arr.size()>0)
			a=1;
		Assert.assertEquals(a,1);
	}
	@Test
	public void testNegativeCase() 
	{
		List<PlaceAnOrderProduct> arr = new ArrayList();
		arr = p.placeAnOrder();
		if(arr.size()>0)
			a=1;
		Assert.assertNotEquals(1,a);
		List<PlaceAnOrderRawMaterial> arr1 = new ArrayList();
		arr1 = r.placeAnOrder();
		if(arr.size()>0)
			a=1;
		Assert.assertNotEquals(1,a);
	}

}
