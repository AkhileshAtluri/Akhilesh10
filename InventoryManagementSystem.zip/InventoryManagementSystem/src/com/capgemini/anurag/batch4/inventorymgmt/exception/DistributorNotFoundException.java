package com.capgemini.anurag.batch4.inventorymgmt.exception;

public class DistributorNotFoundException extends Exception
{
	public DistributorNotFoundException()
	{
		super("Please Enter Valid Distributor Id");
	}
}
