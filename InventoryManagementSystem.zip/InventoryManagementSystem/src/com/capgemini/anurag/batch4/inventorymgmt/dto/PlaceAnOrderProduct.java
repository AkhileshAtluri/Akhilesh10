package com.capgemini.anurag.batch4.inventorymgmt.dto;

import java.util.Date;

public class PlaceAnOrderProduct
{
	private String name;
	private double distributorId;
	private double wareHouseId;
	private double quantityValue;
	private double quantityUnit;
	private double pricePerUnit;
	private Date dateOfDelivery;
	public PlaceAnOrderProduct(){}
	public PlaceAnOrderProduct(String name, double distributorId, double wareHouseId, double quantityValue, int quantityUnit,
			double pricePerUnit, Date dateOfDelivery) {
		super();
		this.name = name;
		this.distributorId = distributorId;
		this.wareHouseId = wareHouseId;
		this.quantityValue = quantityValue;
		this.quantityUnit = quantityUnit;
		this.pricePerUnit = pricePerUnit;
		this.dateOfDelivery = dateOfDelivery;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getDistributorId() {
		return distributorId;
	}
	public void setDistributorId(double distributorId) {
		this.distributorId = distributorId;
	}
	public double getWareHouseId() {
		return wareHouseId;
	}
	public void setWareHouseId(double wareHouseId) {
		this.wareHouseId = wareHouseId;
	}
	public double getQuantityValue() {
		return quantityValue;
	}
	public void setQuantityValue(double quantityValue) {
		this.quantityValue = quantityValue;
	}
	public double getQuantityUnit() {
		return quantityUnit;
	}
	public void setQuantityUnit(double quantityUnit) {
		this.quantityUnit = quantityUnit;
	}
	public double getPricePerUnit() {
		return pricePerUnit;
	}
	public void setPricePerUnit(double pricePerUnit) {
		this.pricePerUnit = pricePerUnit;
	}
	public Date getDateOfDelivery() {
		return dateOfDelivery;
	}
	public void setDateOfDelivery(Date dateOfDelivery) {
		this.dateOfDelivery = dateOfDelivery;
	}
	
}
