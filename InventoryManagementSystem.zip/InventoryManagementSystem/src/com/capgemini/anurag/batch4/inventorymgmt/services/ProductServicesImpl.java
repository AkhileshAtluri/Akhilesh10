package com.capgemini.anurag.batch4.inventorymgmt.services;

import java.util.List;

import com.capgemini.anurag.batch4.inventorymgmt.dao.ProductDao;
import com.capgemini.anurag.batch4.inventorymgmt.dao.ProductDaoImpl;
import com.capgemini.anurag.batch4.inventorymgmt.dto.DisplayProduct;
import com.capgemini.anurag.batch4.inventorymgmt.dto.PlaceAnOrderProduct;
import com.capgemini.anurag.batch4.inventorymgmt.dto.UpdateAnOrderProduct;

public class ProductServicesImpl implements ProductServices
{
	ProductDao dao = new ProductDaoImpl();
	@Override
	public List<PlaceAnOrderProduct> placeAnOrder() {
		return dao.placeAnOrder();
	}
	
	@Override
	public DisplayProduct display(double distributorId) {
		return dao.display(distributorId);
	}

	@Override
	public int updateAnOrder(UpdateAnOrderProduct u) {
		return dao.updateAnOrder(u);
	}
	
}
