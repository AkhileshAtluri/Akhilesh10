package com.capgemini.anurag.batch4.inventorymgmt.dao;

import java.util.List;

import com.capgemini.anurag.batch4.inventorymgmt.dto.DisplayRawMaterial;
import com.capgemini.anurag.batch4.inventorymgmt.dto.PlaceAnOrderRawMaterial;
import com.capgemini.anurag.batch4.inventorymgmt.dto.UpdateAnOrderRawMaterial;

public interface RawMaterialDao 
{
	public void openConnection();
	public void close();
	public List<PlaceAnOrderRawMaterial> placeAnOrder();
	public int updateAnOrder(UpdateAnOrderRawMaterial u);
	public DisplayRawMaterial display(double supplierId);
}
