package com.capgemini.anurag.batch4.inventorymgmt.dao;

import java.util.List;

import com.capgemini.anurag.batch4.inventorymgmt.dto.DisplayProduct;
import com.capgemini.anurag.batch4.inventorymgmt.dto.PlaceAnOrderProduct;
import com.capgemini.anurag.batch4.inventorymgmt.dto.UpdateAnOrderProduct;

public interface ProductDao 
{
	public void openConnection();
	public void close();
	public List<PlaceAnOrderProduct> placeAnOrder();
	public int updateAnOrder(UpdateAnOrderProduct u);
	public DisplayProduct display(double distributorid);
}
