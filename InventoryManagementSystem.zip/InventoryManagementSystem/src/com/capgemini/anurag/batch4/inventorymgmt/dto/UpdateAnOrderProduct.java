package com.capgemini.anurag.batch4.inventorymgmt.dto;

public class UpdateAnOrderProduct 
{
	private double orderId;
	private String productName; 
	private double distributorId;
	private double wareHouseId;
	private double quantityValue;
	private String deliveryStatus;
	public UpdateAnOrderProduct(){}
	public UpdateAnOrderProduct(double orderId, String productName, double distributorId,
			double wareHouseId, double quantityValue, String deliveryStatus) {
		super();
		this.orderId = orderId;
		this.deliveryStatus = deliveryStatus;
		this.productName = productName;
		this.distributorId = distributorId;
		this.wareHouseId = wareHouseId;
		this.quantityValue = quantityValue;
	}
	public double getOrderId() {
		return orderId;
	}
	public void setOrderId(double orderId) {
		this.orderId = orderId;
	}
	public String getDeliveryStatus() {
		return deliveryStatus;
	}
	public void setDeliveryStatus(String deliveryStatus) {
		this.deliveryStatus = deliveryStatus;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public double getDistributorId() {
		return distributorId;
	}
	public void setDistributorId(double distributorId) {
		this.distributorId = distributorId;
	}
	public double getWareHouseId() {
		return wareHouseId;
	}
	public void setWareHouseId(double wareHouseId) {
		this.wareHouseId = wareHouseId;
	}
	public double getQuantityValue() {
		return quantityValue;
	}
	public void setQuantityValue(double quantityValue) {
		this.quantityValue = quantityValue;
	}
	
}
