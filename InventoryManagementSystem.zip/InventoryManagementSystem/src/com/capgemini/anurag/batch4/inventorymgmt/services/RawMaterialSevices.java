package com.capgemini.anurag.batch4.inventorymgmt.services;

import java.util.List;

import com.capgemini.anurag.batch4.inventorymgmt.dto.DisplayRawMaterial;
import com.capgemini.anurag.batch4.inventorymgmt.dto.PlaceAnOrderProduct;
import com.capgemini.anurag.batch4.inventorymgmt.dto.PlaceAnOrderRawMaterial;
import com.capgemini.anurag.batch4.inventorymgmt.dto.UpdateAnOrderRawMaterial;

public interface RawMaterialSevices 
{
	public List<PlaceAnOrderRawMaterial> placeAnOrder();
	public int updateAnOrder(UpdateAnOrderRawMaterial u);
	public DisplayRawMaterial display(double supplierId);
}
