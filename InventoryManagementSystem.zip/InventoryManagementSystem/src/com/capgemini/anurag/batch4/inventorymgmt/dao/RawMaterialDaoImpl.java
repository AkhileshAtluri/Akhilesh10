package com.capgemini.anurag.batch4.inventorymgmt.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.anurag.batch4.inventorymgmt.dto.DisplayRawMaterial;
import com.capgemini.anurag.batch4.inventorymgmt.dto.PlaceAnOrderRawMaterial;
import com.capgemini.anurag.batch4.inventorymgmt.dto.UpdateAnOrderProduct;
import com.capgemini.anurag.batch4.inventorymgmt.dto.UpdateAnOrderRawMaterial;
import com.capgemini.anurag.batch4.inventorymgmt.utility.Queries;

public class RawMaterialDaoImpl implements RawMaterialDao
{
	private Connection connection = null;
	private PreparedStatement pst;
	private ResultSet result,result1;
	@Override
	public void openConnection() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@localhost:1521:xe";
			connection = DriverManager.getConnection(url, "Akhilesh", "akhil");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void close() {
		try {
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public DisplayRawMaterial display(double supplierId) {
		openConnection();
		DisplayRawMaterial rm = null;
		try {
			pst = connection.prepareStatement(Queries.rawMaterialInfo);
			pst.setDouble(1, supplierId);
			result = pst.executeQuery();
			if(result.next())
			{
				rm = new DisplayRawMaterial();
				rm.setOrderId(result.getString(1));
				rm.setName(result.getString(2));
				rm.setPricePerUnit(result.getDouble(3));
				rm.setQuantityValue(result.getDouble(4));
				rm.setQuantityUnit(result.getDouble(5));
				rm.setPrice(result.getDouble(6));
				rm.setWareHouseId(result.getString(7));
				rm.setDeliveryDate(result.getDate(8));
				rm.setManufactureDate(result.getDate(9));
				rm.setExpiryDate(result.getDate(10));
				rm.setQualityCheck(result.getString(11));
				rm.setProcessDate(result.getDate(12));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return rm;
	}

	@Override
	public int updateAnOrder(UpdateAnOrderRawMaterial u)
	{
		openConnection();
		int rows = 0;
		UpdateAnOrderRawMaterial u1 = null;
		try {
			u1 = new UpdateAnOrderRawMaterial();
			pst = connection.prepareStatement(Queries.insertRawMaterial);
			pst.setDouble(1, u1.getOrderId());
			pst.setString(2, u1.getProductName());
			pst.setDouble(3, u1.getSupplierId());
			pst.setDouble(4, u1.getQuantityValue());
			pst.setDouble(5, u1.getWareHouseId());
			pst.setString(6, u1.getDeliveryStatus());
			pst.execute();
			rows++;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		close();
		return rows;
	}

	@Override
	public List<PlaceAnOrderRawMaterial> placeAnOrder() 
	{
		openConnection();
		List<PlaceAnOrderRawMaterial> rmlist = new ArrayList<>();
		try {
			pst = connection.prepareStatement(Queries.rawMaterialDetails);
			result1 = pst.executeQuery();
			while(result1.next())
			{
				PlaceAnOrderRawMaterial p = new PlaceAnOrderRawMaterial();
				p.setName(result1.getString(1));
				p.setSupplierId(result1.getDouble(2));
				p.setWareHouseId(result1.getDouble(3));
				p.setPricePerUnit(result1.getDouble(4));
				rmlist.add(p);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		close();
		return rmlist;
	}

}
