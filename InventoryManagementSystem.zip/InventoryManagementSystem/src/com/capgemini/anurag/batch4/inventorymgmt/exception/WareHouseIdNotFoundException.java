package com.capgemini.anurag.batch4.inventorymgmt.exception;

public class WareHouseIdNotFoundException extends Exception
{
	public WareHouseIdNotFoundException()
	{
		super("Please Enter Valid WareHouseId");
	}
}
