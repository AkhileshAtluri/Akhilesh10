package com.capgemini.anurag.batch4.inventorymgmt.exception;

public class SupplierNotFoundException extends Exception
{
	public SupplierNotFoundException()
	{
		super("Please Enter Available Supplier Id");
	}
}
