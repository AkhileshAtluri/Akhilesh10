package com.capgemini.anurag.batch4.inventorymgmt.dto;

public class UpdateAnOrderRawMaterial 
{
	private double orderId;
	private String deliveryStatus;
	private String productName; 
	private double supplierId;
	private double wareHouseId;
	private double quantityValue;
	public UpdateAnOrderRawMaterial(){}
	public UpdateAnOrderRawMaterial(double orderId, String deliveryStatus, String productName, double supplierId,
			double wareHouseId, double quantityValue) {
		super();
		this.orderId = orderId;
		this.deliveryStatus = deliveryStatus;
		this.productName = productName;
		this.supplierId = supplierId;
		this.wareHouseId = wareHouseId;
		this.quantityValue = quantityValue;
	}
	public double getOrderId() {
		return orderId;
	}
	public void setOrderId(double orederId) {
		this.orderId = orederId;
	}
	public String getDeliveryStatus() {
		return deliveryStatus;
	}
	public void setDeliveryStatus(String deliveryStatus) {
		this.deliveryStatus = deliveryStatus;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public double getSupplierId() {
		return supplierId;
	}
	public void setSupplierId(double supplierId) {
		this.supplierId = supplierId;
	}
	public double getWareHouseId() {
		return wareHouseId;
	}
	public void setWareHouseId(double wareHouseId) {
		this.wareHouseId = wareHouseId;
	}
	public double getQuantityValue() {
		return quantityValue;
	}
	public void setQuantityValue(double quantityValue) {
		this.quantityValue = quantityValue;
	}
	
}
