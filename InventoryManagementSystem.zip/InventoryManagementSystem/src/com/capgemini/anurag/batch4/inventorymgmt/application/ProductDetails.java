package com.capgemini.anurag.batch4.inventorymgmt.application;

import com.capgemini.anurag.batch4.inventorymgmt.dto.DisplayProduct;
import com.capgemini.anurag.batch4.inventorymgmt.dto.PlaceAnOrderProduct;
import com.capgemini.anurag.batch4.inventorymgmt.dto.UpdateAnOrderProduct;
import com.capgemini.anurag.batch4.inventorymgmt.services.ProductServices;
import com.capgemini.anurag.batch4.inventorymgmt.services.ProductServicesImpl;
import com.capgemini.anurag.batch4.inventorymgmt.exception.DistributorNotFoundException;
import com.capgemini.anurag.batch4.inventorymgmt.exception.ProductNotFoundException;
import com.capgemini.anurag.batch4.inventorymgmt.exception.WareHouseIdNotFoundException;

import java.util.List;
import java.util.Scanner;
public class ProductDetails {

	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		ProductServices ps = new ProductServicesImpl();
		try
		{
			List<PlaceAnOrderProduct> plist = ps.placeAnOrder();
			System.out.println("Name\t\tdistributorid\twarehouseid\tpriceperunit");
			for(PlaceAnOrderProduct p : plist)
			System.out.println(p.getName()+"\t"+p.getDistributorId()+"\t\t"+p.getWareHouseId()+"\t\t"+p.getPricePerUnit());
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		System.out.println("Enter Product Name to be Order");
		String productName = sc.nextLine();
		System.out.println("Enter Distributor Id");
		double distributorId = sc.nextDouble();
		System.out.println("Enter WareHouse Id");
		double wareHouseId = sc.nextDouble();
		System.out.println("Enter Quantity Required");
		double quantityValue = sc.nextDouble();
		double orderId = 1;
		UpdateAnOrderProduct u1 = new UpdateAnOrderProduct(orderId, productName, distributorId, wareHouseId, quantityValue,"Shipping");
		try
		{
			int rows = ps.updateAnOrder(u1);
			if(rows>0)
				System.out.println("Updated");
			else
				System.out.println("Not Updated");
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		try
		{
		DisplayProduct dp = ps.display(25);
		System.out.println(dp.getOrderId()+" "+dp.getName()+" "+dp.getPricePerUnit()+" "+
		dp.getQuantityValue()+" "+dp.getQuantityUnit()+" "+dp.getPrice()+" "+dp.getWareHouseId()+
		" "+dp.getDeliveryDate()+" "+dp.getManufactureDate()+" "+dp.getExpiryDate()+" "+
		dp.getQualityCheck()+" "+dp.getProcessDate());
		}
		catch(NullPointerException e)
		{
			System.out.println("No Product");
		}
	}

}
