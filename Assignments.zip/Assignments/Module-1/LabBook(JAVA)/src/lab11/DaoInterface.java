package lab11;

public interface DaoInterface {
	public void add(Employee e);
	public Employee selectData(int nid);
}

