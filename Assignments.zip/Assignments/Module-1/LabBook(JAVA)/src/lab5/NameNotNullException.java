package lab5;
public class NameNotNullException extends Exception 
{
	public NameNotNullException()
	{
		super("Name Should not be Null");
	}
}
