package lab2;

public class Main {

}
