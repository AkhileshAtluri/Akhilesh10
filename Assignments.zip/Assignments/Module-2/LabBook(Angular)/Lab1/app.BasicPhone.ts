export class BasicPhone
{
  mobileType:string;
  public constructor(mobileType:string)
  {
    this.mobileType = mobileType;
  }
}